//
//  Cheat.cpp
//  CallOfDutyMenu
//
//  Created by Ts1 on 22/05/2025.
//

#include "Cheat.hpp"

char* BinaryName = "cod";

bool Cheats::isRecoilUpBaseEnabled              = false;
bool Cheats::isRecoilUpModifierEnabled          = false;
bool Cheats::isRecoilUpMaxEnabled               = false;
bool Cheats::isRecoilLateralEnabled             = false;
bool Cheats::isRecoilLateralModifierEnabled     = false;
bool Cheats::isRecoilLateralMaxEnabled          = false;
bool Cheats::isUAVEnabled                       = false;
bool Cheats::isAdvUAVEnabled                    = false;


float(*oldRecoilUpBase)(void* instance);
float(*oldRecoilUpModifier)(void* instance);
float(*oldRecoilUpMax)(void* instance);
float(*oldRecoilLateralBase)(void* instance);
float(*oldRecoilLateralModifier)(void* instance);
float(*oldRecoilLateralMax)(void* instance);
bool(*oldUAV)(void* instance);
bool(*oldAdvUAV)(void* instance);

float Cheats::RecoilUpBase(void* instance) {
    if(instance != nullptr){
        if (Cheats::isRecoilUpBaseEnabled) {
            return 0.0f;
        }
    }
    return oldRecoilUpBase(instance);
}

float Cheats::RecoilUpModifier(void* instance) {
    if(instance != nullptr){
        if (Cheats::isRecoilUpModifierEnabled){
            return 0.0f;
        }
    }
    return oldRecoilUpModifier(instance);
}

float Cheats::RecoilUpMaxCheat(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isRecoilUpMaxEnabled) {
            return 0.0f;
        }
    }
    return oldRecoilUpMax(instance);
}

//---------------------------------//

float Cheats::RecoilLateralCheat(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isRecoilLateralEnabled) {
            return 0.0F;
        }
    }
    return oldRecoilLateralBase(instance);
}

float Cheats::RecoilLateralModifier(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isRecoilLateralModifierEnabled) {
            return 0.0F;
        }
    }
    return oldRecoilLateralModifier(instance);
}

float Cheats::RecoilLateralMax(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isRecoilLateralMaxEnabled) {
            return 0.0F;
        }
    }
    return oldRecoilLateralMax(instance);
}

bool Cheats::UAVEnabled(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isUAVEnabled)
        {
            return true;
        }
    }
    return oldUAV(instance);
}

bool Cheats::AdvancedUAVEnabled(void *instance) {
    if (instance != nullptr) {
        if (Cheats::isAdvUAVEnabled)
        {
            return true;
        }
    }
    return oldAdvUAV(instance);
}


void Cheats::LoadMods() {
    HOOK(0x23A5ADC, Cheats::RecoilUpBase, oldRecoilUpBase); // public float RecoilUpBase() { }
    HOOK(0x23A62E4, Cheats::RecoilUpModifier, oldRecoilUpModifier); // public float RecoilUpModifier() { }
    HOOK(0x23A8290, Cheats::RecoilUpMaxCheat, oldRecoilUpMax); // public float RecoilUpMax() { }
    
    HOOK(0x23A5EE0, Cheats::RecoilLateralCheat, oldRecoilLateralBase); // public float RecoilLateralBase() { }
    HOOK(0x23A66E8, Cheats::RecoilLateralModifier, oldRecoilLateralModifier); // public float RecoilLateralModifier() { }
    HOOK(0x23A869C, Cheats::RecoilLateralMax, oldRecoilLateralMax); // public float RecoilLateralMax() { }
    
    HOOK(0x1EF6CA0, Cheats::UAVEnabled, oldUAV); // protected virtual bool F_UAVEnabled() { }
    HOOK(0x1EF7224, Cheats::AdvancedUAVEnabled, oldAdvUAV); // public virtual bool get_AdvanceUAVEnabled() { }
}

